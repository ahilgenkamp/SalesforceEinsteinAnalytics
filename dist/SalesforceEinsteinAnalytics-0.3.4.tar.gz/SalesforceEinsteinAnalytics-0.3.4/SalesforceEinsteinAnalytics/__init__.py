from SalesforceEinsteinAnalytics.SFDC_EA import salesforceEinsteinAnalytics
__version__ = '0.3.5'
